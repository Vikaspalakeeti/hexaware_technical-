package com.hexaware.fooddelivery.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class RestaurantsServiceImpTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
